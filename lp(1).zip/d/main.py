from mainTeste import *

atualizaCadastroUsuario()