
def menus():
    print("\n\n [1] - USUARIOS ")
    print("\n\n [2] - LIVROS   ")
    print("\n\n [3] - EMPRESTIMOS")
    print("\n\n [0] - SAIR")


def menuUsuario():
    print("\n\n [1] - ATUALIZAR CADASTRO USUARIO ")
    print("\n\n [2] - BUSCAR INFORMAÇÕES DO USUARIO ")
    print("\n\n [3] - CADASTRAR NOVO USUARIO ")
    print("\n\n [0] - SAIR")


def menuLivro():
    print("\n\n [1] - BUSCAR LIVRO ")
    print("\n\n [2] - CADASTRAR LIVRO ")
    print("\n\n [3] - EMPRESTAR LIVRO ")
    print("\n\n [0] - SAIR")


def menuEmprestimo():
    print("\n\n [1] - DEVOLVER LIVRO ")
    print("\n\n [2] - RENOVAR EMPRESTIMO ")
    print("\n\n [3] - BUSCAR EMPRESTIMOS ")
    print("\n\n [0] - SAIR")


